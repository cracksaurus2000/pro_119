# PRO_C119_PP_V1
FILOSOFÍA DE UN CHATBOT  
Python. NLTK.  
  
Preprocesamiento de datos.  
  
### Texto en inglés: PRO-C119-Project-Boilerplate
